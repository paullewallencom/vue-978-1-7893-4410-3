Vue.component('custom-article', {
    template: `
      <article>
        Our own custom article component!<span></span>
      </article>`
  })
  new Vue({
      el: '#app'
  })  