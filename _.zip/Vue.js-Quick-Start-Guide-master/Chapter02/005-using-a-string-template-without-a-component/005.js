new Vue({
    el: '#app',
    template: '<article>A string template without a component!<span></span></article>'
})