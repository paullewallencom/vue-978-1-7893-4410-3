new Vue({
  el: '#app',
  data() {
    return {
      btnClicked: false,
      btnPrimary: 'btn btn-lg btn-primary bounce animated',
      btnSecondary: 'btn btn-lg btn-secondary tada animated'
    }
  }
})