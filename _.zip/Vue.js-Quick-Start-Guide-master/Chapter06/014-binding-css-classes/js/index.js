new Vue({
  el: '#app',
  data() {
    return {
      btnClicked: false,
    }
  }
})